@echo off
chcp 65001 >nul
powershell.exe -STA -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0apply-ui-fix.ps1"
pause
