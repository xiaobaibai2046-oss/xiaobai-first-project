@echo off
chcp 65001 >nul
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0source\windows-dzh-auto\remove-task.ps1"
pause
